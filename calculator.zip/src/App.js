import React from "react";
import DISPLAY from "./Components/display";
import KEYPAD from "./Components/keypad";
import "./App.css";


export default class App extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            result:"0"
        }
    }

    calculate = () => {
        try{
            this.setState({
                result: (eval(this.state.result))
            })
            
        }
        catch{
            this.setState({result:"ERROR!!!"})
        }
    };

    backspace = () =>{
        this.setState({result:this.state.result.slice(0,-1)})
    };

    reset = () =>{
        this.setState({result:"0"})
    };

    onClick = button =>{
        if(button === "=" || button === "Enter"){
            this.calculate()
        }

        else if(button === "C"){
            this.backspace()
        }

        else if(button === "CE"){
            this.reset()
        }

        else if(button ==="%"){
            this.setState({result: this.state.result/100})
        }
        else{
            if(this.state.result==="0"){
                this.setState({result: button})    
            }
            else{
            this.setState({result:this.state.result + button})
            }
        }
    };

    componentDidMount(){
        document.addEventListener("keydown", this.onKeyPress)
    }

    onKeyPress = event =>{
        if(event.key === "=" || event.key === "Enter"){
            this.calculate()
        }

        else if(event.key === "Backspace"){
            this.backspace()
        }

        else if(event.key === "Delete"){
            this.reset()
        }
        else if(event.key === "Shift"){
            
        }
        else if(event.key === "Capslock"){
            
        }
        else if(event.key === "Alt"){
            
        }
        else if(event.key ==="%"){
            this.setState({result: this.state.result/100})
        }
        else{
            if(this.state.result==="0"){
                this.setState({result: event.key})    
            }
            else{
            this.setState({result:this.state.result + event.key})
            }
        }
    };



    render(){
        return(
            <div>
                <h1 className="header">Calculator</h1>
                <div className="flex">
                    <div className="body">
                        <DISPLAY result={this.state.result} onKeyPress={this.onKeyPress} />
                        <KEYPAD onClick={this.onClick}  />
                    </div>
                </div>
                <footer className="footer">Made by Vibhor Khanna in {new Date().getFullYear()}</footer>
            </div>
        );
    }
}