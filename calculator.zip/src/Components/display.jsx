import React from "react";
import "./display.css";

export default class Display extends React.Component{
    render(){
        let {result} = this.props;
        return(
            <div className="center">
                <div className="display">
                    <p>{result}</p>
                </div>
            </div>
        );
    }
    
}